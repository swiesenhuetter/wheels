##################################################################################################
##
# ACS Motion Control Ltd.
# Copyright © 1999 - 2024. All Rights Reserved.
##
# PROJECT			:    SPiiPlus
# SUBSYSTEM		:    SPiiPlus Python Package
# FILE				:	 SPiiPlusEnums.py
# VERSION			:    7.4.0.0
# OVERVIEW
# ========
##
# SPiiPlus Python Package export functions definition
##
##################################################################################################


# Generated at 20/05/2024 13:26:18

from SPiiPlusPython.SPiiPlusDefs.SPiiPlusEnums import *


class ACSCtypesStructure(ct.Structure):
	def __eq__(self, other):
		if type(self) != type(other):
			return False

		for fld in self._fields_:
			if isinstance(getattr(self, fld[0]), ct.Array):
				if getattr(self, fld[0])[:] != getattr(other, fld[0])[:]:
					return False
			elif getattr(self, fld[0]) != getattr(other, fld[0]):
				return False
		return True

	def __ne__(self, other):
		if self == other:
			return False
		return True


# Define the in_addr struct in Python
class in_addr_c(ACSCtypesStructure):
	_fields_ = [('s_addr', ct.c_uint32)]


class FRD_c(ACSCtypesStructure):
	_fields_ = [('real', ct.c_void_p),
				('imag', ct.c_void_p),
				('frequencyHz', ct.c_void_p),
				('length', ct.c_uint),
]


class FRF_STABILITY_MARGINS_c(ACSCtypesStructure):
	_fields_ = [('gainMarginArray', ct.c_void_p),
				('gainMarginArrayFrequencyHz', ct.c_void_p),
				('gainMarginArrayLength', ct.c_uint),
				('gainMarginWorst', ct.c_double),
				('gainMarginWorstFrequencyHz', ct.c_double),
				('phaseMarginArray', ct.c_void_p),
				('phaseMarginArrayFrequencyHz', ct.c_void_p),
				('phaseMarginArrayLength', ct.c_uint),
				('phaseMarginWorst', ct.c_double),
				('phaseMarginWorstFrequencyHz', ct.c_double),
				('modulusMargin', ct.c_double),
				('modulusMarginFrequencyHz', ct.c_double),
				('bandwidth', ct.c_double),
]


class FRF_DURATION_CALCULATION_PARAMETERS_c(ACSCtypesStructure):
	_fields_ = [('frequencyDistributionType', FRF_FREQUENCY_DISTRIBUTION_TYPE),
				('startFreqHz', ct.c_double),
				('endFreqHz', ct.c_double),
				('freqPerDec', ct.c_int),
				('highResolutionStart', ct.c_double),
				('highResolutionFreqPerDec', ct.c_int),
				('frequencyHzResolutionForLinear', ct.c_double),
]


class FRF_INPUT_c(ACSCtypesStructure):
# User defined excitation signal
# Quick recalculate without remeasuring
	_fields_ = [('axis', ct.c_int),
				('loopType', FRF_LOOP_TYPE),
				('excitationType', FRF_EXCITATION_TYPE),
				('chirpType', FRF_CHIRP_TYPE),
				('windowType', FRF_WINDOW_TYPE),
				('frequencyDistributionType', FRF_FREQUENCY_DISTRIBUTION_TYPE),
				('overlap', FRF_OVERLAP),
				('startFreqHz', ct.c_double),
				('endFreqHz', ct.c_double),
				('freqPerDec', ct.c_int),
				('excitationAmplitudePercentIp', ct.c_double),
				('numberOfRepetitions', ct.c_int),
				('highResolutionStart', ct.c_double),
				('highResolutionFreqPerDec', ct.c_int),
				('durationSec', ct.c_double),
				('userDefinedExcitationSignal', ct.c_void_p),
				('userDefinedExcitationSignalLength', ct.c_int),
				('inRaw', ct.c_void_p),
				('outRaw', ct.c_void_p),
				('lengthRaw', ct.c_int),
				('recalculate', ct.c_bool),
]


class FRF_OUTPUT_c(ACSCtypesStructure):
# Plant parameters
	_fields_ = [('plant', ct.c_void_p),
				('controller', ct.c_void_p),
				('openLoop', ct.c_void_p),
				('closedLoop', ct.c_void_p),
				('sensitivity', ct.c_void_p),
				('coherence', ct.c_void_p),
				('stabilityMargins', ct.c_void_p),
				('loopType', FRF_LOOP_TYPE),
				('inRaw', ct.c_void_p),
				('outRaw', ct.c_void_p),
				('lengthRaw', ct.c_int),
				('excitationAmplitude', ct.c_double),
				('plantVelocityToPosition', ct.c_void_p),
				('coherenceVelocityToPosition', ct.c_void_p),
]


class FILTER_ROUTING_c(ACSCtypesStructure):
	_fields_ = [('SLVNFRQ0', ct.c_double),
				('SLVNWID0', ct.c_double),
				('SLVNATT0', ct.c_double),
				('SLVB0NF0', ct.c_double),
				('SLVB0DF0', ct.c_double),
				('SLVB0ND0', ct.c_double),
				('SLVB0DD0', ct.c_double),
				('SLVB1NF0', ct.c_double),
				('SLVB1DF0', ct.c_double),
				('SLVB1ND0', ct.c_double),
				('SLVB1DD0', ct.c_double),
				('SLVNFRQ1', ct.c_double),
				('SLVNWID1', ct.c_double),
				('SLVNATT1', ct.c_double),
				('SLVB0NF1', ct.c_double),
				('SLVB0DF1', ct.c_double),
				('SLVB0ND1', ct.c_double),
				('SLVB0DD1', ct.c_double),
				('SLVB1NF1', ct.c_double),
				('SLVB1DF1', ct.c_double),
				('SLVB1ND1', ct.c_double),
				('SLVB1DD1', ct.c_double),
				('SLVNFRQ2', ct.c_double),
				('SLVNWID2', ct.c_double),
				('SLVNATT2', ct.c_double),
				('SLVB0NF2', ct.c_double),
				('SLVB0DF2', ct.c_double),
				('SLVB0ND2', ct.c_double),
				('SLVB0DD2', ct.c_double),
				('SLVB1NF2', ct.c_double),
				('SLVB1DF2', ct.c_double),
				('SLVB1ND2', ct.c_double),
				('SLVB1DD2', ct.c_double),
				('SLVNFRQ3', ct.c_double),
				('SLVNWID3', ct.c_double),
				('SLVNATT3', ct.c_double),
				('SLVB0NF3', ct.c_double),
				('SLVB0DF3', ct.c_double),
				('SLVB0ND3', ct.c_double),
				('SLVB0DD3', ct.c_double),
				('SLVB1NF3', ct.c_double),
				('SLVB1DF3', ct.c_double),
				('SLVB1ND3', ct.c_double),
				('SLVB1DD3', ct.c_double),
				('MFLAGS0', ct.c_int32),
				('MFLAGS1', ct.c_int32),
				('MFLAGS2', ct.c_int32),
				('MFLAGS3', ct.c_int32),
]


class SERVO_PARAMETERS_c(ACSCtypesStructure):
# FILTER_ROUTING* FilterRoutingPtr;
	_fields_ = [('SLIKP', ct.c_double),
				('SLIKI', ct.c_double),
				('SLILI', ct.c_double),
				('SLPKP', ct.c_double),
				('SLPKI', ct.c_double),
				('SLPLI', ct.c_double),
				('SLVKP', ct.c_double),
				('SLVKI', ct.c_double),
				('SLVLI', ct.c_double),
				('SLVSOF', ct.c_double),
				('SLVSOFD', ct.c_double),
				('SLVNFRQ', ct.c_double),
				('SLVNWID', ct.c_double),
				('SLVNATT', ct.c_double),
				('SLVB0NF', ct.c_double),
				('SLVB0DF', ct.c_double),
				('SLVB0ND', ct.c_double),
				('SLVB0DD', ct.c_double),
				('SLVB1NF', ct.c_double),
				('SLVB1DF', ct.c_double),
				('SLVB1ND', ct.c_double),
				('SLVB1DD', ct.c_double),
				('XVEL', ct.c_double),
				('EFAC', ct.c_double),
				('SLVRAT', ct.c_double),
				('SLAFF', ct.c_double),
				('MFLAGS', ct.c_int32),
				('MFLAGSX', ct.c_int32),
				('FilterRouting', FILTER_ROUTING_c),
]


class FRF_CALCULATE_LOOP_DATA_c(ACSCtypesStructure):
# Plant parameters
	_fields_ = [('plant', ct.c_void_p),
				('plantVelocityToPosition', ct.c_void_p),
				('servoParameters', ct.c_void_p),
				('dataType', FRF_DATA_TYPE),
				('measureLoopType', FRF_LOOP_TYPE),
				('targetLoopType', FRF_LOOP_TYPE),
]


class FRF_CALCULATE_SLVRAT_DATA_c(ACSCtypesStructure):
	_fields_ = [('plantVelocityToPosition', ct.c_void_p),
				('startFrequencyHz', ct.c_double),
				('endFrequencyHz', ct.c_double),
]


class JITTER_ANALYSIS_INPUT_c(ACSCtypesStructure):
# Jitter array
# Parameters for frequency bands cumulative analysis
# Window type. Applied to a signal in time domain
	_fields_ = [('jitter', ct.c_void_p),
				('jitterLength', ct.c_uint),
				('samplingFrequencyHz', ct.c_uint),
				('desiredFrequencyResolutionHz', ct.c_double),
				('jitterFrequencyBandsCumulativeAmplitudeRMSthreshold', ct.c_void_p),
				('frequencyBandsHz', ct.c_void_p),
				('frequencyBandsHzLength', ct.c_uint),
				('windowType', FRF_WINDOW_TYPE),
]


class JITTER_ANALYSIS_OUTPUT_c(ACSCtypesStructure):
# following three arrays have the same length defined in frequencyLength
# Result of frequency bands cumulative analysis
	_fields_ = [('jitterAmplitudeRMS', ct.c_void_p),
				('jitterCumulativeAmplitudeRMS', ct.c_void_p),
				('frequencyHz', ct.c_void_p),
				('frequencyLength', ct.c_uint),
				('jitterFrequencyBandsCumulativeAmplitudeRMS', ct.c_void_p),
				('frequencyBandsHz', ct.c_void_p),
				('frequencyBandsHzLength', ct.c_uint),
				('jitterFrequencyBandsResultBool', ct.c_int),
				('jitterRMS', ct.c_double),
				('jitterAmplitudePeak2Peak', ct.c_double),
]


class FRF_CROSS_COUPLING_INPUT_c(ACSCtypesStructure):
# User defined excitation signal
	_fields_ = [('axes', ct.c_void_p),
				('axesLength', ct.c_int),
				('crossCouplingType', FRF_CROSS_COUPLING_TYPE),
				('excitationType', FRF_EXCITATION_TYPE),
				('chirpType', FRF_CHIRP_TYPE),
				('windowType', FRF_WINDOW_TYPE),
				('frequencyDistributionType', FRF_FREQUENCY_DISTRIBUTION_TYPE),
				('overlap', FRF_OVERLAP),
				('startFreqHz', ct.c_double),
				('endFreqHz', ct.c_double),
				('freqPerDec', ct.c_int),
				('excitationAmplitudePercentIp', ct.c_void_p),
				('numberOfRepetitions', ct.c_int),
				('highResolutionStart', ct.c_double),
				('highResolutionFreqPerDec', ct.c_int),
				('durationSec', ct.c_double),
				('userDefinedExcitationSignal', ct.c_void_p),
				('userDefinedExcitationSignalLength', ct.c_int),
				('customOutputName', ct.c_void_p),
				('customOutputNode', ct.c_int),
				('customInputName', ct.c_void_p),
				('customInputNode', ct.c_int),
				('customInputScale', ct.c_double),
				('customInputOffset', ct.c_double),
]


class FRF_CROSS_COUPLING_OUTPUT_c(ACSCtypesStructure):
	_fields_ = [('plant', ct.c_void_p),
				('controller', ct.c_void_p),
				('characteristicPolynomial', ct.c_void_p),
				('closedLoop', ct.c_void_p),
				('sensitivity', ct.c_void_p),
				('coherencePS', ct.c_void_p),
				('coherenceS', ct.c_void_p),
				('RGA', ct.c_void_p),
				('stabilityMargins', ct.c_void_p),
				('crossCouplingType', FRF_CROSS_COUPLING_TYPE),
				('excitationAmplitude', ct.c_void_p),
				('matrixSize', ct.c_int),
]


class ACSC_PCI_SLOT_c(ACSCtypesStructure):
	_fields_ = [('BusNumber', ct.c_uint),
				('SlotNumber', ct.c_uint),
				('Function', ct.c_uint)]


class PCI_SLOT_c(ACSCtypesStructure):
	_fields_ = [('BusNumber', ct.c_uint),
				('SlotNumber', ct.c_uint),
				('Function', ct.c_uint)]


class ACSC_CONNECTION_DESC_c(ACSCtypesStructure):
	_fields_ = [('Application', ct.c_char * 100),
				('Handle', ct.c_void_p),
				('ProcessId', ct.c_uint)]


class ACSC_CONNECTION_INFO_c(ACSCtypesStructure):
	_fields_ = [('Type', ACSC_CONNECTION_TYPE),
				('SerialPort', ct.c_int),
				('SerialBaudRate', ct.c_int),
				('PCISlot', ct.c_int),
				('EthernetProtocol', ct.c_int),
				('EthernetIP', ct.c_char * 100),
				('EthernetPort', ct.c_int)]


class ACSC_APPSL_STRING_c(ACSCtypesStructure):
	_fields_ = [('length', ct.c_int),
				('string', ct.c_void_p)]


class ACSC_APPSL_SECTION_c(ACSCtypesStructure):
	_fields_ = [('type', ACSC_APPSL_FILETYPE),
				('filename', ACSC_APPSL_STRING_c),
				('description', ACSC_APPSL_STRING_c),
				('size', ct.c_uint),
				('offset', ct.c_uint),
				('CRC', ct.c_uint),
				('inuse', ct.c_int),
				('error', ct.c_int),
				('data', ct.c_void_p)]


class ACSC_APPSL_ATTRIBUTE_c(ACSCtypesStructure):
	_fields_ = [('key', ACSC_APPSL_STRING_c),
				('value', ACSC_APPSL_STRING_c)]


class ACSC_APPSL_INFO_c(ACSCtypesStructure):
	_fields_ = [('filename', ACSC_APPSL_STRING_c),
				('description', ACSC_APPSL_STRING_c),
				('isNewFile', ct.c_int),
				('ErrCode', ct.c_int),
				('attributes_num', ct.c_uint),
				('attributes', ct.c_void_p),
				('sections_num', ct.c_uint),
				('sections', ct.c_void_p)]


class ACSC_HISTORYBUFFER_c(ACSCtypesStructure):
	_fields_ = [('Max', ct.c_int),
				('Cur', ct.c_int),
				('Ring', ct.c_int),
				('Buf', ct.c_void_p),
]


class ACSC_CONTROLLER_INFO_c(ACSCtypesStructure):
	_fields_ = [('IpAddress', in_addr_c),
				('SerialNumber', ct.c_char * 100),
				('PartNumber', ct.c_char * 100),
				('Version', ct.c_char * 100),
]


class AXMASK_EXT_c(ACSCtypesStructure):
	_fields_ = [('AXMASK64', ct.c_uint64),
				('AXMASK128', ct.c_uint64),
				('Reserved1', ct.c_uint64),
				('Reserved2', ct.c_uint64)]
