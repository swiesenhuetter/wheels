from os import path, add_dll_directory
import sys
import time

sys.path.append(path.dirname(__file__))


package_path = path.dirname(__file__)
add_dll_directory(path.join(package_path, 'lib'))

print(f"you are here: {__file__}")
from PrecitecCHRoco2 import PrecitecCHRoco2, configure, print_status, PeakOrderingBy
from chrocodile_gms.CHRoco2 import Chr2Exception


croc2 = PrecitecCHRoco2()
v = croc2.version()
print('c++ extension version {} loaded'.format(v))


try:
    croc2.open_connection("192.168.253.2")
except Chr2Exception as err:
    print(err)
    exit(0)


print('connected')
croc2.stop_data_streaming()
configure(croc2)
croc2.set_peak_ordering(PeakOrderingBy.PeakValueAscending)
print_status(croc2)
croc2.start_data_streaming()
time.sleep(1)
data = []
print_status(croc2)
for n in range(20):
    sample = croc2.get_last_sample()
    data.append(sample)
    time.sleep(0.1)

for sample in data:
    print("gap: {}µm, quality: {}, intensity: {}".format(*sample))

croc2.stop_data_streaming()
croc2.close_connection()
print('disconnected')

