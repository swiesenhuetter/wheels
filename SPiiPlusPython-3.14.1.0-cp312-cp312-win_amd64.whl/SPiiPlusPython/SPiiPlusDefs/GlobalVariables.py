import ctypes as ct


SYNCHRONOUS = ct.c_void_p(0)
IGNORE = ct.c_void_p(-1)
INFINITE = -1

class AcsError:
	pass

