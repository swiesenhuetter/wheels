import photonics_laser as pl

def res_print(res, what=""):
    print(f"{what}: {pl.ToString(res.error_code)}")
    if res.is_error:
        print (f"Error msg: {res.error_message}")

laser = pl.Laser("simulate dx")
res = laser.ConnectByRS232(3)
res_print(res, "connect")

res = laser.IsOutput()
print(f"Output state = {res}")

print("Enable Output")
res = laser.EnableOutput()
res_print(res,"enable")

res = laser.SetPRF(70000)
res_print(res, "set freq.")
res = laser.SetPEC(80.0)
res_print(res, "set pulse energy")

res = laser.IsOutput()
print(f"Output state = {res}")

laser.DisableOutput()
summary = laser.GetInformationSummary()
print(f"Laser Info: {summary}")
